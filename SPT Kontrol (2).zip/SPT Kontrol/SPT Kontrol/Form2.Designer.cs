﻿namespace SPT_Kontrol
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            TreeNode treeNode1 = new TreeNode("001");
            TreeNode treeNode2 = new TreeNode("003");
            TreeNode treeNode3 = new TreeNode("004");
            TreeNode treeNode4 = new TreeNode("008");
            TreeNode treeNode5 = new TreeNode("009н00");
            TreeNode treeNode6 = new TreeNode("009н01");
            TreeNode treeNode7 = new TreeNode("009н02");
            TreeNode treeNode8 = new TreeNode("009н03");
            TreeNode treeNode9 = new TreeNode("009н04");
            TreeNode treeNode10 = new TreeNode("009н05");
            TreeNode treeNode11 = new TreeNode("009н06");
            TreeNode treeNode12 = new TreeNode("009н07");
            TreeNode treeNode13 = new TreeNode("009н08");
            TreeNode treeNode14 = new TreeNode("009н09");
            TreeNode treeNode15 = new TreeNode("009н10");
            TreeNode treeNode16 = new TreeNode("009н11");
            TreeNode treeNode17 = new TreeNode("009н12");
            TreeNode treeNode18 = new TreeNode("009н13");
            TreeNode treeNode19 = new TreeNode("009н14");
            TreeNode treeNode20 = new TreeNode("009н15");
            TreeNode treeNode21 = new TreeNode("009н16");
            TreeNode treeNode22 = new TreeNode("009н17");
            TreeNode treeNode23 = new TreeNode("009н18");
            TreeNode treeNode24 = new TreeNode("009н19");
            TreeNode treeNode25 = new TreeNode("009н20");
            TreeNode treeNode26 = new TreeNode("009н21");
            TreeNode treeNode27 = new TreeNode("009", new TreeNode[] { treeNode5, treeNode6, treeNode7, treeNode8, treeNode9, treeNode10, treeNode11, treeNode12, treeNode13, treeNode14, treeNode15, treeNode16, treeNode17, treeNode18, treeNode19, treeNode20, treeNode21, treeNode22, treeNode23, treeNode24, treeNode25, treeNode26 });
            TreeNode treeNode28 = new TreeNode("011");
            TreeNode treeNode29 = new TreeNode("012");
            TreeNode treeNode30 = new TreeNode("013н00");
            TreeNode treeNode31 = new TreeNode("013н01");
            TreeNode treeNode32 = new TreeNode("013н02");
            TreeNode treeNode33 = new TreeNode("013н03");
            TreeNode treeNode34 = new TreeNode("013н04");
            TreeNode treeNode35 = new TreeNode("013н05");
            TreeNode treeNode36 = new TreeNode("013н06");
            TreeNode treeNode37 = new TreeNode("013н07");
            TreeNode treeNode38 = new TreeNode("013н08");
            TreeNode treeNode39 = new TreeNode("013н09");
            TreeNode treeNode40 = new TreeNode("013н10");
            TreeNode treeNode41 = new TreeNode("013н11");
            TreeNode treeNode42 = new TreeNode("013н12");
            TreeNode treeNode43 = new TreeNode("013н13");
            TreeNode treeNode44 = new TreeNode("013н14");
            TreeNode treeNode45 = new TreeNode("013н15");
            TreeNode treeNode46 = new TreeNode("013н16");
            TreeNode treeNode47 = new TreeNode("013н17");
            TreeNode treeNode48 = new TreeNode("013н18");
            TreeNode treeNode49 = new TreeNode("013н19");
            TreeNode treeNode50 = new TreeNode("013н20");
            TreeNode treeNode51 = new TreeNode("013", new TreeNode[] { treeNode30, treeNode31, treeNode32, treeNode33, treeNode34, treeNode35, treeNode36, treeNode37, treeNode38, treeNode39, treeNode40, treeNode41, treeNode42, treeNode43, treeNode44, treeNode45, treeNode46, treeNode47, treeNode48, treeNode49, treeNode50 });
            TreeNode treeNode52 = new TreeNode("0", new TreeNode[] { treeNode1, treeNode2, treeNode3, treeNode4, treeNode27, treeNode28, treeNode29, treeNode51 });
            TreeNode treeNode53 = new TreeNode("100");
            TreeNode treeNode54 = new TreeNode("101");
            TreeNode treeNode55 = new TreeNode("т1", new TreeNode[] { treeNode53, treeNode54 });
            TreeNode treeNode56 = new TreeNode("СПТ962", new TreeNode[] { treeNode52, treeNode55 });
            menuStrip1 = new MenuStrip();
            fileToolStripMenuItem = new ToolStripMenuItem();
            NewBDToolStripMenuItem = new ToolStripMenuItem();
            SPT963ToolStripMenuItem = new ToolStripMenuItem();
            SPT962ToolStripMenuItem = new ToolStripMenuItem();
            OpenProjectToolStripMenuItem = new ToolStripMenuItem();
            exitToolStripMenuItem = new ToolStripMenuItem();
            helpToolStripMenuItem = new ToolStripMenuItem();
            SpravkaToolStripMenuItem = new ToolStripMenuItem();
            ExitMainToolStripMenuItem = new ToolStripMenuItem();
            panel2 = new Panel();
            label1 = new Label();
            timer1 = new System.Windows.Forms.Timer(components);
            flowLayoutPanel1 = new FlowLayoutPanel();
            panel7 = new Panel();
            buttonXdbOutput = new Button();
            treeView1 = new TreeView();
            timer2 = new System.Windows.Forms.Timer(components);
            timer3 = new System.Windows.Forms.Timer(components);
            timer4 = new System.Windows.Forms.Timer(components);
            timer5 = new System.Windows.Forms.Timer(components);
            timer6 = new System.Windows.Forms.Timer(components);
            timer7 = new System.Windows.Forms.Timer(components);
            flowLayoutPanel3 = new FlowLayoutPanel();
            panel3 = new Panel();
            label3 = new Label();
            tabControlElement = new TabControl();
            tabPage1 = new TabPage();
            label6 = new Label();
            textBox1 = new TextBox();
            label5 = new Label();
            label13 = new Label();
            panel5 = new Panel();
            panel1 = new Panel();
            panel6 = new Panel();
            label2 = new Label();
            panelElement = new Panel();
            dataGridView1 = new DataGridView();
            panel4 = new Panel();
            button8 = new Button();
            pictureBox2 = new PictureBox();
            label4 = new Label();
            panel8 = new Panel();
            menuStrip1.SuspendLayout();
            panel2.SuspendLayout();
            flowLayoutPanel1.SuspendLayout();
            panel7.SuspendLayout();
            flowLayoutPanel3.SuspendLayout();
            panel3.SuspendLayout();
            tabControlElement.SuspendLayout();
            tabPage1.SuspendLayout();
            panel1.SuspendLayout();
            panel6.SuspendLayout();
            panelElement.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel8.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.BackColor = Color.DeepSkyBlue;
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { fileToolStripMenuItem, helpToolStripMenuItem, ExitMainToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(1206, 24);
            menuStrip1.Stretch = false;
            menuStrip1.TabIndex = 1;
            menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            fileToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { NewBDToolStripMenuItem, OpenProjectToolStripMenuItem, exitToolStripMenuItem });
            fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            fileToolStripMenuItem.Size = new Size(48, 20);
            fileToolStripMenuItem.Text = "Фаил";
            // 
            // NewBDToolStripMenuItem
            // 
            NewBDToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { SPT963ToolStripMenuItem, SPT962ToolStripMenuItem });
            NewBDToolStripMenuItem.Name = "NewBDToolStripMenuItem";
            NewBDToolStripMenuItem.Size = new Size(162, 22);
            NewBDToolStripMenuItem.Text = "Создать БД";
            // 
            // SPT963ToolStripMenuItem
            // 
            SPT963ToolStripMenuItem.Name = "SPT963ToolStripMenuItem";
            SPT963ToolStripMenuItem.Size = new Size(118, 22);
            SPT963ToolStripMenuItem.Text = "СПТ 963";
            SPT963ToolStripMenuItem.Click += SPT963ToolStripMenuItem_Click;
            // 
            // SPT962ToolStripMenuItem
            // 
            SPT962ToolStripMenuItem.Name = "SPT962ToolStripMenuItem";
            SPT962ToolStripMenuItem.Size = new Size(118, 22);
            SPT962ToolStripMenuItem.Text = "СПТ 962";
            SPT962ToolStripMenuItem.Click += SPT962ToolStripMenuItem_Click;
            // 
            // OpenProjectToolStripMenuItem
            // 
            OpenProjectToolStripMenuItem.Name = "OpenProjectToolStripMenuItem";
            OpenProjectToolStripMenuItem.Size = new Size(162, 22);
            OpenProjectToolStripMenuItem.Text = "Открыть проект";
            OpenProjectToolStripMenuItem.Click += OpenProjectToolStripMenuItem_Click;
            // 
            // exitToolStripMenuItem
            // 
            exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            exitToolStripMenuItem.Size = new Size(162, 22);
            exitToolStripMenuItem.Text = "Выход";
            exitToolStripMenuItem.Click += exitToolStripMenuItem_Click;
            // 
            // helpToolStripMenuItem
            // 
            helpToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { SpravkaToolStripMenuItem });
            helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            helpToolStripMenuItem.Size = new Size(68, 20);
            helpToolStripMenuItem.Text = "Помощь";
            // 
            // SpravkaToolStripMenuItem
            // 
            SpravkaToolStripMenuItem.Name = "SpravkaToolStripMenuItem";
            SpravkaToolStripMenuItem.Size = new Size(120, 22);
            SpravkaToolStripMenuItem.Text = "Справка";
            SpravkaToolStripMenuItem.Click += SpravkaToolStripMenuItem_Click;
            // 
            // ExitMainToolStripMenuItem
            // 
            ExitMainToolStripMenuItem.Name = "ExitMainToolStripMenuItem";
            ExitMainToolStripMenuItem.Size = new Size(98, 20);
            ExitMainToolStripMenuItem.Text = "Выход в меню";
            ExitMainToolStripMenuItem.Click += ExitMainToolStripMenuItem_Click;
            // 
            // panel2
            // 
            panel2.BackColor = SystemColors.ControlLightLight;
            panel2.Controls.Add(label1);
            panel2.Location = new Point(3, 3);
            panel2.Name = "panel2";
            panel2.Size = new Size(249, 43);
            panel2.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(52, 7);
            label1.Name = "label1";
            label1.Size = new Size(110, 22);
            label1.TabIndex = 3;
            label1.Text = "Параметры";
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.AllowDrop = true;
            flowLayoutPanel1.AutoScroll = true;
            flowLayoutPanel1.BackColor = Color.DeepSkyBlue;
            flowLayoutPanel1.Controls.Add(panel2);
            flowLayoutPanel1.Controls.Add(panel7);
            flowLayoutPanel1.Dock = DockStyle.Left;
            flowLayoutPanel1.Location = new Point(0, 24);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(278, 721);
            flowLayoutPanel1.TabIndex = 5;
            // 
            // panel7
            // 
            panel7.Controls.Add(buttonXdbOutput);
            panel7.Controls.Add(treeView1);
            panel7.Location = new Point(3, 52);
            panel7.Name = "panel7";
            panel7.Size = new Size(250, 653);
            panel7.TabIndex = 4;
            // 
            // buttonXdbOutput
            // 
            buttonXdbOutput.Location = new Point(9, 609);
            buttonXdbOutput.Name = "buttonXdbOutput";
            buttonXdbOutput.Size = new Size(228, 41);
            buttonXdbOutput.TabIndex = 1;
            buttonXdbOutput.Text = "Вывод в Xdb";
            buttonXdbOutput.UseVisualStyleBackColor = true;
            buttonXdbOutput.Click += buttonXdbOutput_Click;
            // 
            // treeView1
            // 
            treeView1.Location = new Point(9, 21);
            treeView1.Name = "treeView1";
            treeNode1.Name = "parametr-001";
            treeNode1.Text = "001";
            treeNode2.Name = "parametr-003";
            treeNode2.Text = "003";
            treeNode3.Name = "parametr-004";
            treeNode3.Text = "004";
            treeNode4.Name = "parametr-008";
            treeNode4.Text = "008";
            treeNode5.Name = "parametr-009n00";
            treeNode5.Text = "009н00";
            treeNode6.Name = "parametr-009n01";
            treeNode6.Text = "009н01";
            treeNode7.Name = "parametr-009n02";
            treeNode7.Text = "009н02";
            treeNode8.Name = "parametr-009n03";
            treeNode8.Text = "009н03";
            treeNode9.Name = "parametr-009n04";
            treeNode9.Text = "009н04";
            treeNode10.Name = "parametr-009n05";
            treeNode10.Text = "009н05";
            treeNode11.Name = "parametr-009n06";
            treeNode11.Text = "009н06";
            treeNode12.Name = "parametr-009n07";
            treeNode12.Text = "009н07";
            treeNode13.Name = "parametr-009n08";
            treeNode13.Text = "009н08";
            treeNode14.Name = "parametr-009n09";
            treeNode14.Text = "009н09";
            treeNode15.Name = "parametr-009n10";
            treeNode15.Text = "009н10";
            treeNode16.Name = "parametr-009n11";
            treeNode16.Text = "009н11";
            treeNode17.Name = "parametr-009n12";
            treeNode17.Text = "009н12";
            treeNode18.Name = "parametr-009n13";
            treeNode18.Text = "009н13";
            treeNode19.Name = "parametr-009n14";
            treeNode19.Text = "009н14";
            treeNode20.Name = "parametr-009n15";
            treeNode20.Text = "009н15";
            treeNode21.Name = "parametr-009n16";
            treeNode21.Text = "009н16";
            treeNode22.Name = "parametr-009n17";
            treeNode22.Text = "009н17";
            treeNode23.Name = "parametr-009n18";
            treeNode23.Text = "009н18";
            treeNode24.Name = "parametr-009n19";
            treeNode24.Text = "009н19";
            treeNode25.Name = "parametr-009n20";
            treeNode25.Text = "009н20";
            treeNode26.Name = "parametr-009n21";
            treeNode26.Text = "009н21";
            treeNode27.Name = "parametr-009";
            treeNode27.Text = "009";
            treeNode28.Name = "parametr-011";
            treeNode28.Text = "011";
            treeNode29.Name = "parametr-012";
            treeNode29.Text = "012";
            treeNode30.Name = "parametr-013n00";
            treeNode30.Text = "013н00";
            treeNode31.Name = "parametr-013n01";
            treeNode31.Text = "013н01";
            treeNode32.Name = "parametr-013n02";
            treeNode32.Text = "013н02";
            treeNode33.Name = "parametr-013n03";
            treeNode33.Text = "013н03";
            treeNode34.Name = "parametr-013n04";
            treeNode34.Text = "013н04";
            treeNode35.Name = "parametr-013n05";
            treeNode35.Text = "013н05";
            treeNode36.Name = "parametr-013n06";
            treeNode36.Text = "013н06";
            treeNode37.Name = "parametr-013n07";
            treeNode37.Text = "013н07";
            treeNode38.Name = "parametr-013n08";
            treeNode38.Text = "013н08";
            treeNode39.Name = "parametr-013n09";
            treeNode39.Text = "013н09";
            treeNode40.Name = "parametr-013n10";
            treeNode40.Text = "013н10";
            treeNode41.Name = "parametr-013n11";
            treeNode41.Text = "013н11";
            treeNode42.Name = "parametr-013n12";
            treeNode42.Text = "013н12";
            treeNode43.Name = "parametr-013n13";
            treeNode43.Text = "013н13";
            treeNode44.Name = "parametr-013n14";
            treeNode44.Text = "013н14";
            treeNode45.Name = "parametr-013n15";
            treeNode45.Text = "013н15";
            treeNode46.Name = "parametr-013n16";
            treeNode46.Text = "013н16";
            treeNode47.Name = "parametr-013n17";
            treeNode47.Text = "013н17";
            treeNode48.Name = "parametr-013n18";
            treeNode48.Text = "013н18";
            treeNode49.Name = "parametr-013n19";
            treeNode49.Text = "013н19";
            treeNode50.Name = "parametr-013n20";
            treeNode50.Text = "013н20";
            treeNode51.Name = "parametr-013";
            treeNode51.Text = "013";
            treeNode52.Name = "0";
            treeNode52.Text = "0";
            treeNode53.Name = "parametr-100";
            treeNode53.Text = "100";
            treeNode54.Name = "parametr-101";
            treeNode54.Text = "101";
            treeNode55.Name = "т";
            treeNode55.Text = "т1";
            treeNode56.Name = "TSPT962";
            treeNode56.Text = "СПТ962";
            treeView1.Nodes.AddRange(new TreeNode[] { treeNode56 });
            treeView1.Size = new Size(228, 582);
            treeView1.TabIndex = 0;
            treeView1.AfterSelect += treeView1_AfterSelect;
            // 
            // flowLayoutPanel3
            // 
            flowLayoutPanel3.Controls.Add(panel3);
            flowLayoutPanel3.Controls.Add(tabControlElement);
            flowLayoutPanel3.Location = new Point(277, 393);
            flowLayoutPanel3.Name = "flowLayoutPanel3";
            flowLayoutPanel3.Size = new Size(448, 352);
            flowLayoutPanel3.TabIndex = 8;
            // 
            // panel3
            // 
            panel3.BackColor = Color.DeepSkyBlue;
            panel3.Controls.Add(label3);
            panel3.Location = new Point(3, 3);
            panel3.Name = "panel3";
            panel3.Size = new Size(445, 35);
            panel3.TabIndex = 9;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(149, 5);
            label3.Name = "label3";
            label3.Size = new Size(112, 18);
            label3.TabIndex = 0;
            label3.Text = "Конфигурация";
            // 
            // tabControlElement
            // 
            tabControlElement.Controls.Add(tabPage1);
            tabControlElement.Location = new Point(3, 44);
            tabControlElement.Name = "tabControlElement";
            tabControlElement.SelectedIndex = 0;
            tabControlElement.Size = new Size(444, 308);
            tabControlElement.TabIndex = 1;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(label6);
            tabPage1.Controls.Add(textBox1);
            tabPage1.Controls.Add(label5);
            tabPage1.Controls.Add(label13);
            tabPage1.Location = new Point(4, 24);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(436, 280);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Информация";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(14, 68);
            label6.Name = "label6";
            label6.Size = new Size(65, 15);
            label6.TabIndex = 19;
            label6.Text = "Описание:";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(14, 101);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(404, 152);
            textBox1.TabIndex = 18;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(195, 14);
            label5.Name = "label5";
            label5.Size = new Size(58, 15);
            label5.TabIndex = 17;
            label5.Text = "значение";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label13.Location = new Point(14, 16);
            label13.Name = "label13";
            label13.Size = new Size(150, 15);
            label13.TabIndex = 16;
            label13.Text = "Значение по-умолчанию:";
            // 
            // panel5
            // 
            panel5.BackColor = Color.PaleTurquoise;
            panel5.Location = new Point(727, 28);
            panel5.Name = "panel5";
            panel5.Size = new Size(4, 717);
            panel5.TabIndex = 10;
            // 
            // panel1
            // 
            panel1.Controls.Add(panel6);
            panel1.Location = new Point(280, 28);
            panel1.Name = "panel1";
            panel1.Size = new Size(448, 367);
            panel1.TabIndex = 11;
            // 
            // panel6
            // 
            panel6.BackColor = Color.DeepSkyBlue;
            panel6.Controls.Add(label2);
            panel6.Location = new Point(0, 0);
            panel6.Name = "panel6";
            panel6.Size = new Size(446, 38);
            panel6.TabIndex = 10;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(125, 6);
            label2.Name = "label2";
            label2.Size = new Size(157, 18);
            label2.TabIndex = 0;
            label2.Text = "Настройки элемента";
            // 
            // panelElement
            // 
            panelElement.AllowDrop = true;
            panelElement.Controls.Add(dataGridView1);
            panelElement.Location = new Point(280, 72);
            panelElement.Name = "panelElement";
            panelElement.Size = new Size(446, 320);
            panelElement.TabIndex = 1;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Dock = DockStyle.Fill;
            dataGridView1.Location = new Point(0, 0);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(446, 320);
            dataGridView1.TabIndex = 0;
            dataGridView1.CellClick += dataGridView1_CellClick;
            // 
            // panel4
            // 
            panel4.BackColor = SystemColors.ControlLightLight;
            panel4.Controls.Add(button8);
            panel4.Controls.Add(pictureBox2);
            panel4.Location = new Point(730, 31);
            panel4.Name = "panel4";
            panel4.Size = new Size(476, 714);
            panel4.TabIndex = 16;
            // 
            // button8
            // 
            button8.Location = new Point(64, 451);
            button8.Name = "button8";
            button8.Size = new Size(43, 43);
            button8.TabIndex = 17;
            button8.Text = "1";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources._51b654517cd5ff96bac6468bf51255d8;
            pictureBox2.Location = new Point(8, 116);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(459, 378);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 0;
            pictureBox2.TabStop = false;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(92, 5);
            label4.Name = "label4";
            label4.Size = new Size(251, 18);
            label4.TabIndex = 0;
            label4.Text = "Графический интерфейс прибора";
            // 
            // panel8
            // 
            panel8.BackColor = Color.DeepSkyBlue;
            panel8.Controls.Add(label4);
            panel8.Location = new Point(730, 29);
            panel8.Name = "panel8";
            panel8.Size = new Size(476, 35);
            panel8.TabIndex = 10;
            // 
            // Form2
            // 
            AutoScaleMode = AutoScaleMode.None;
            ClientSize = new Size(1206, 745);
            Controls.Add(panel8);
            Controls.Add(panel4);
            Controls.Add(panelElement);
            Controls.Add(panel1);
            Controls.Add(panel5);
            Controls.Add(flowLayoutPanel1);
            Controls.Add(menuStrip1);
            Controls.Add(flowLayoutPanel3);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Name = "Form2";
            Text = "SPT Kontroller - СПТ962";
            Load += Form2_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            flowLayoutPanel1.ResumeLayout(false);
            panel7.ResumeLayout(false);
            flowLayoutPanel3.ResumeLayout(false);
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            tabControlElement.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            panel1.ResumeLayout(false);
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            panelElement.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel8.ResumeLayout(false);
            panel8.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem fileToolStripMenuItem;
        private ToolStripMenuItem NewBDToolStripMenuItem;
        private ToolStripMenuItem SPT963ToolStripMenuItem;
        private ToolStripMenuItem SPT962ToolStripMenuItem;
        private ToolStripMenuItem OpenProjectToolStripMenuItem;
        private ToolStripMenuItem exitToolStripMenuItem;
        private ToolStripMenuItem helpToolStripMenuItem;
        private ToolStripMenuItem SpravkaToolStripMenuItem;
        private Panel panel2;
        private Label label1;
        private System.Windows.Forms.Timer timer1;
        private FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.Timer timer4;
        private System.Windows.Forms.Timer timer5;
        private System.Windows.Forms.Timer timer6;
        private System.Windows.Forms.Timer timer7;
        private FlowLayoutPanel flowLayoutPanel3;
        private Panel panel3;
        private Label label3;
        private Panel panel5;
        private Panel panel1;
        private Panel panel6;
        private Label label2;
        private Panel panelElement;
        private TabControl tabControlElement;
        private TabPage tabPage1;
        private Label label13;
        private Panel panel4;
        private PictureBox pictureBox2;
        private Label label4;
        private Panel panel8;
        private Button button8;
        private Panel panel7;
        private TreeView treeView1;
        private Button buttonXdbOutput;
        private DataGridView dataGridView1;
        private Label label6;
        private TextBox textBox1;
        private Label label5;
        private ToolStripMenuItem ExitMainToolStripMenuItem;
    }
}